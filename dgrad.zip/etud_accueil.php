	<style>
		.acte_p{margin:0px;padding:0px;}
		.acte_p label{width:75px;float:left;font-weight:bold}
		.acte_p select,.acte_p input{width:200px;}
		#table_ordonnancer_note input{width:100%}
		#id_lien_rapp a{margin-right:10px}
	</style>
				
	<div id='div_ordonnancement' style='width:40%;margin:auto;text-align:center' >
		<h3>Bureau Etudes et Contentieux</h3>
		<?php echo "<img src='".$_SESSION["snp"]['user']['src_str_img']."' style='width:200px;margin:auto' />";?>
		<br/><br/>Vous êtes au bureau contentieux, si vous ne vous retrouvez pas, c.à.d que vous ne devriez pas être là; il s'agit peut-être d'une erreur de programmation alors dépechez-vous d'aller voir l'administrateur de l'application afin de regler cet ennui.
	
	</div>
	