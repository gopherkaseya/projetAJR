<?php 
$_POST = $_GET;
require_once("traitement_sup.php");