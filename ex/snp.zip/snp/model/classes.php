<?php 
		require_once('model/connexion.php');
		require_once('model/chado.php');
		require_once('model/fonctions_sup.php');
		
		require_once('model/Utilisateur.php');
		require_once('model/Visites.php');
		require_once('model/UserClasse.php');
		require_once('model/Classe_in_Code.php');
		
		
		require_once('model/Actes.php');
		require_once('model/Assujetti.php');
		require_once('model/Banque.php');
		require_once('model/Carnet.php');
		require_once('model/CarnetAttribuer.php');
		require_once('model/CarnetLot.php');
		require_once('model/Commune.php');
		require_once('model/ComServ.php');
		require_once('model/Note.php');
		require_once('model/NoteActe.php');
		require_once('model/NoteActesPayer.php');
		require_once('model/Releve.php');
		require_once('model/Service.php');
		require_once('model/User.php');