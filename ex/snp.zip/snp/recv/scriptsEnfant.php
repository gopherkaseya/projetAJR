
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
	<link href="enfants_fichiers/normalize.css" rel="stylesheet" type="text/css">
    <link href="enfants_fichiers/css.css" rel="stylesheet" type="text/css">
    <link href="enfants_fichiers/Site.css" rel="stylesheet" type="text/css">

    <link href="enfants_fichiers/highlight.css" rel="stylesheet" type="text/css">
	<link href="enfants_fichiers/shCore.css" rel="stylesheet" type="text/css">
	<!--link href="enfants_fichiers/jtable.css" rel="stylesheet" type="text/css"-->
    <link href="enfants_fichiers/jquery-ui.css" rel="stylesheet" type="text/css">
	<link href="enfants_fichiers/shThemeDefault.css" rel="stylesheet" type="text/css">
	<link href="enfants_fichiers/validationEngine.css" rel="stylesheet" type="text/css">
	<link href='Scripts/jtable/themes/metro/blue/jtable.css' rel='stylesheet' type='text/css' />
	

    <script src="enfants_fichiers/ga_002.js" async="" type="text/javascript"></script><script src="enfants_fichiers/ca-pub-1219224739916003.js" type="text/javascript" async=""></script><script src="enfants_fichiers/widgets.js" id="twitter-wjs"></script><script src="enfants_fichiers/ga.js" async="" type="text/javascript"></script><script src="enfants_fichiers/modernizr-2.js" type="text/javascript"></script>
    <script src="enfants_fichiers/jquery-1.js" type="text/javascript"></script>
    <script src="enfants_fichiers/jquery-ui-1.js" type="text/javascript"></script>
    <script src="enfants_fichiers/shCore.js" type="text/javascript"></script>
    <script src="enfants_fichiers/shBrushJScript.js" type="text/javascript"></script>
    <script src="enfants_fichiers/shBrushXml.js" type="text/javascript"></script>
    <script src="enfants_fichiers/shBrushCSharp.js" type="text/javascript"></script>
    <script src="enfants_fichiers/shBrushSql.js" type="text/javascript"></script>
    <script src="enfants_fichiers/shBrushPhp.js" type="text/javascript"></script>
    <script src="enfants_fichiers/jtablesite.js" type="text/javascript"></script>
    <script src="enfants_fichiers/jquery_002.js" type="text/javascript" ></script>
    
    <script src="enfants_fichiers/jquery.js" type="text/javascript"></script>
    <script src="enfants_fichiers/jquery_003.js" type="text/javascript"></script>
	
	<script src='Scripts/jtable/localization/jquery.jtable.fr.js' type='text/javascript'></script>
	