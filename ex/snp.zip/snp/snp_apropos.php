<h1>S.N.P</h1>
Outil informatique de suivi de note de perception.</br>
Réalisé depuis 2015 par un group de jeunes étudiant fraichement sortis d'ESIS.</br>
Revu et amélioré en 2016 par l'un d'entre eux que vous pouvez joindre au 085 14 91 971 ou 097 16 95 208.</br>
